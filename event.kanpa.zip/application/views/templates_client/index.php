<?php $this->load->view('templates_client/header'); ?>
<?php $this->load->view('templates_client/navbar'); ?>
<?php $this->load->view($content); ?>
<?php $this->load->view('templates_client/footer'); ?>
<?php $this->load->view('templates_client/footer_js'); ?>